import React from "react";
import ReactDOM from "react-dom";

import "./styles.css";

function App() {
  return (
    <div className="App">
      <h1>Encontre.me</h1>
      <input type="text" placeholder="Nome:" />
      <input type="text" placeholder="Email:" />
      <input type="text" placeholder="Senha:" />
      <input type="text" placeholder="Confirmar senha:" />
      <input class="btn" type="submit" value="Confirmar" />
      <br />
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
